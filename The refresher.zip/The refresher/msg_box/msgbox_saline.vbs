Dim result, objShell, scriptPath
Set objShell = CreateObject("WScript.Shell")

' Récupérer le dossier où se trouve le script VBS
scriptPath = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)

' Afficher le message box
result = MsgBox("Are you sure you want to execute this? [about sensitive people!]", vbYesNo + vbQuestion, "Warning")

If result = vbYes Then
    MsgBox "Executing...", vbExclamation, "Process Started"
    objShell.CurrentDirectory = scriptPath
    objShell.Run """..\crashpad\salinewin-safety.exe""", 0, False
Else
	End If
