@echo off

cd /d "%~dp0"
title Finisher refresh pad
echo DONT CLOSE ME! im not done.
timeout 1 >nul
color 0A
timeout 1 >nul
color 0B
timeout 1 >nul
color 0C
timeout 1 >nul
color 0D
timeout 1 >nul
color 0E
timeout 1 >nul
color 0F
timeout 1 >nul
color 03
timeout 1 >nul
color 02
timeout 1 >nul
color 0A
timeout 1 >nul
color 0B
timeout 1 >nul
color 0C
timeout 1 >nul
color 0D
timeout 1 >nul
color 0E
timeout 1 >nul
color 0F
timeout 1 >nul
color 03
timeout 1 >nul
color 02
timeout 1 >nul
color 0A
timeout 1 >nul
color 0B
timeout 1 >nul
color 0C
timeout 1 >nul
color 0D
timeout 1 >nul
color 0E
timeout 1 >nul
color 0F
timeout 1 >nul
color 03
timeout 1 >nul
color 02
timeout 1 >nul
::preparé les MessageBox [temporaire]
powershell -Command "Add-Type -AssemblyName PresentationFramework; [System.Windows.MessageBox]::Show('fatal error')"
powershell -Command "Add-Type -AssemblyName PresentationFramework; [System.Windows.MessageBox]::Show('It is n-o-t done yet!')"
::FERMER TOUT!
timeout
	end(
exit cd