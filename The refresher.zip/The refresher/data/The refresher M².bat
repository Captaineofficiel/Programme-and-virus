@echo off

:: Lancement du programme...
echo loading...
timeout 3 >nul

:: Le menu
:loop
title Killer windows V.8
cls    
timeout 2 >nul
color 0C
for /f "tokens=2 delims==" %%i in ('wmic os get Caption /value') do set OS=%%i                           

echo        Captaine Tools Collections
echo ==========================================
echo             !THE REFRESHER!
echo ==========================================
echo [Current windows on:%OS%]
echo [Edition: Premium] [Version: 8] [Menu: 2]
echo.                                            
echo Tool made by Captaine_Officiel on YouTube.
echo Press [I] to get more information!
echo [This Malware can't damage your Windows system, don't worry!]
echo Press [M] to view all commands.
echo Are you sure you want to kill your Windows? [Y/N]
set /p key=Enter your choice: [THE PROJECT menu2 IS ABANDONNED!]

:: Vérification des choix de l'utilisateur
if /i "%key%"=="I" (
	start "https://github.com/Captaineofficiel"
	exit /b
)
if /i "%key%"=="M" goto menu_des_clé
if /i "%key%"=="Y" goto shutdownW
if /i "%key%"=="N" (
    echo Operation cancelled, shutting down...
    timeout 3 >nul
    exit
)

:: Vérification pour "U"
if /i "%key%"=="U" goto information

:: menu des clés (debug) 
:menu_des_clé
if /i "%key%"=="M" (
    color 0A
    cls
    echo Available commands:
    echo [M] View all commands
    echo [I] More information
    echo [U] Show ip information
    echo [C] multi-color
    echo [K] kick out from windows
    echo [P] For secret words!
    echo [X] For switch menu
    echo [Y] Proceed
    echo [N] Cancel
    pause
    goto loop
)

:: Gestion des commandes non valides
:gestion-des-commandes-non-valides
if /i "%key%"=="X" (
    cls
    color 0B
    echo Not available...
    timeout 3 >nul
    goto loop
)

if /i "%key%"=="P" (
    cls
    color 0B
    echo Not available...
    timeout 3 >nul
    goto loop
)

:: Shutdown windows
:shutdownW
if "%key%"=="K" (
    cls
    echo Breaking permission...
    timeout 2 >nul
    echo success
    timeout 1 >nul 
    shutdown -y
    exit /b
)

:: Vérification de la couleur aléatoire
:colorrandom
if /i "%key%"=="C" (
    timeout 1 >nul
    color 0A
    timeout 1 >nul
    color 0B
    timeout 1 >nul
    color 0C
    timeout 1 >nul
    color 0D
    timeout 1 >nul
    color 0E
    timeout 1 >nul
    color 0F
    timeout 1 >nul
    color 03
    timeout 1 >nul
    color 02
    timeout 1 >nul
    color 0A
    timeout 1 >nul
    color 0B
    timeout 1 >nul
    color 0C
    timeout 1 >nul
    color 0D
    timeout 1 >nul
    color 0E
    timeout 1 >nul
    color 0F
    timeout 1 >nul
    color 03
    timeout 1 >nul
    color 02
    timeout 1 >nul
    color 0C
    goto loop
)

:: Gestion d'une mauvaise entrée
echo Invalid choice.
timeout 2 >nul
goto loop

:: Informations supplémentaires
:information
cls
echo Loading your information...
timeout 2 >nul
cls
ipconfig
pause
goto loop

:: Procéder
:proceed
cls
echo Attempting to connect...
timeout 8 >nul
echo Waiting for action, press Enter to proceed...
pause
cls
echo Attempting to kill Windows...
timeout 5 >nul
echo Destroying desktop...
timeout 5 >nul
cls
echo Error...
timeout 2 >nul
cls
echo Forcing permissions...
timeout 2 >nul
echo Retrying in 5 seconds...
timeout 5 >nul
cls
echo Destroying desktop...
timeout 5 >nul
echo Destroying programs...
timeout 2 >nul
echo Success!
timeout 1 >nul 
taskkill /f /im explorer.exe >nul 2>&1
timeout 1 >nul
exit